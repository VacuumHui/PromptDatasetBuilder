package com.civitared.promptdataset.data

import java.net.URI

object SettingsRules {
    fun normalizeEndpoint(value: String): String {
        var endpoint = value.trim()
        if (endpoint.isBlank()) return AppSettings.DEFAULT_ENDPOINT

        endpoint = when {
            endpoint.startsWith("https://", ignoreCase = true) -> endpoint
            endpoint.startsWith("http://", ignoreCase = true) ->
                "https://${endpoint.substringAfter("://")}" 
            else -> "https://$endpoint"
        }

        endpoint = endpoint
            .substringBefore('#')
            .substringBefore('?')
            .trimEnd('/')

        val uri = runCatching { URI(endpoint) }.getOrNull()
        val host = uri?.host?.lowercase()
        val path = uri?.path.orEmpty()

        if (host == AppSettings.CIVITA_RED_HOST ||
            host == "www.${AppSettings.CIVITA_RED_HOST}"
        ) {
            return AppSettings.CIVITA_RED_ENDPOINT
        }

        if (path.contains("/api/trpc/")) {
            return endpoint
        }

        if (!endpoint.endsWith("/api/v1/images")) {
            endpoint += "/api/v1/images"
        }
        return endpoint
    }

    fun isLegacySourceEndpoint(value: String): Boolean {
        var endpoint = value.trim()
        if (endpoint.isBlank()) return false
        if (!endpoint.startsWith("http://", ignoreCase = true) &&
            !endpoint.startsWith("https://", ignoreCase = true)
        ) {
            endpoint = "https://$endpoint"
        }

        val uri = runCatching { URI(endpoint) }.getOrNull() ?: return false
        val host = uri.host?.lowercase().orEmpty().removePrefix("www.")
        val path = uri.path.orEmpty().trimEnd('/')

        return (host == AppSettings.CIVITA_RED_HOST && path != "/api/trpc/image.getInfinite") ||
            (host == "civitai.com" && path == "/api/v1/images")
    }

    fun validationError(settings: AppSettings): String? = when {
        settings.includeNsfw && !settings.ageConfirmed ->
            "Для NSFW-ленты требуется подтверждение возраста 18+"

        settings.includeNsfw && settings.apiKey.isBlank() ->
            "Для NSFW-ленты укажите пользовательский API-ключ"

        settings.command.isBlank() ->
            "Команда датасета не должна быть пустой"

        else -> null
    }
}
