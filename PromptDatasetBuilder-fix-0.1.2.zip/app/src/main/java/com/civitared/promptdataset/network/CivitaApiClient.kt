package com.civitared.promptdataset.network

import com.civitared.promptdataset.data.AppSettings
import com.civitared.promptdataset.data.ImagePage
import com.civitared.promptdataset.data.SourceImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class CivitaApiClient {
    private val client = OkHttpClient.Builder()
        .cache(null)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun loadPage(
        settings: AppSettings,
        nextUrl: String? = null,
        nextCursor: String? = null,
    ): ImagePage = withContext(Dispatchers.IO) {
        val endpoint = validatedEndpoint(settings.endpoint)
        if (isTrpcEndpoint(endpoint)) {
            loadTrpcPage(settings, endpoint, nextCursor)
        } else {
            loadRestPage(settings, endpoint, nextUrl, nextCursor)
        }
    }

    suspend fun testConnection(settings: AppSettings): Int {
        val page = loadPage(settings.copy(pageSize = 3))
        return page.items.size
    }

    private suspend fun loadTrpcPage(
        settings: AppSettings,
        endpoint: HttpUrl,
        nextCursor: String?,
    ): ImagePage {
        val url = buildTrpcListUrl(settings, endpoint, nextCursor)
        val body = executeJson(url, settings, trpc = true)
        val rawPage = parseTrpcList(body)
        val semaphore = Semaphore(6)

        val items = coroutineScope {
            rawPage.candidates.map { candidate ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        val prompt = candidate.prompt
                            ?: candidate.numericId?.let { imageId ->
                                runCatching {
                                    loadGenerationPrompt(settings, endpoint, imageId)
                                }.getOrNull()
                            }

                        prompt
                            ?.trim()
                            ?.takeIf { it.isNotBlank() && it != "null" }
                            ?.let { candidate.toSourceImage(it) }
                    }
                }
            }.awaitAll().filterNotNull()
        }

        return ImagePage(
            items = items.distinctBy(SourceImage::id),
            nextUrl = null,
            nextCursor = rawPage.nextCursor,
        )
    }

    private fun loadRestPage(
        settings: AppSettings,
        endpoint: HttpUrl,
        nextUrl: String?,
        nextCursor: String?,
    ): ImagePage {
        val url = buildRestUrl(settings, endpoint, nextUrl, nextCursor)
        val body = executeJson(url, settings, trpc = false)
        return runCatching { parseRestPage(body) }.getOrElse { error ->
            throw IOException("API вернул неподдерживаемый JSON: ${error.message}", error)
        }
    }

    private fun executeJson(
        url: String,
        settings: AppSettings,
        trpc: Boolean,
    ): String {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", "PromptDatasetBuilder/0.1.2 Android")
            .apply {
                if (trpc) {
                    header("Content-Type", "application/json")
                    header("x-client-version", "5.0.1386")
                    header("x-client-date", System.currentTimeMillis().toString())
                    header("x-client", "web")
                    header("x-fingerprint", "undefined")
                }
                if (settings.apiKey.isNotBlank()) {
                    header("Authorization", "Bearer ${settings.apiKey.trim()}")
                }
            }
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body.string()
            val contentType = response.header("Content-Type").orEmpty()

            if (looksLikeHtml(body, contentType)) {
                throw IOException(
                    "Сервер ${response.request.url.host} вернул HTML вместо JSON. " +
                        "Для civita.red выберите источник civita.red (tRPC), " +
                        "а не адрес /api/v1/images.",
                )
            }

            if (!response.isSuccessful) {
                val details = extractApiError(body)
                throw IOException(
                    "API вернул ${response.code}: " +
                        details.ifBlank { response.message }.take(350),
                )
            }
            return body
        }
    }

    private fun buildRestUrl(
        settings: AppSettings,
        endpoint: HttpUrl,
        nextUrl: String?,
        nextCursor: String?,
    ): String {
        if (!nextUrl.isNullOrBlank()) {
            val next = nextUrl.toHttpUrlOrNull()
                ?: throw IllegalArgumentException("API вернул некорректный адрес следующей страницы")
            require(next.isHttps && next.host == endpoint.host && next.port == endpoint.port) {
                "API вернул небезопасный адрес следующей страницы"
            }
            return next.toString()
        }

        return endpoint.newBuilder()
            .setQueryParameter("limit", settings.pageSize.toString())
            .setQueryParameter("sort", "Newest")
            .setQueryParameter("period", "AllTime")
            .setQueryParameter("nsfw", if (settings.includeNsfw) "X" else "Safe")
            .apply {
                if (!nextCursor.isNullOrBlank()) {
                    setQueryParameter("cursor", nextCursor)
                }
            }
            .build()
            .toString()
    }

    private fun buildTrpcListUrl(
        settings: AppSettings,
        endpoint: HttpUrl,
        nextCursor: String?,
    ): String {
        val params = JSONObject()
            .put("useIndex", true)
            .put("period", "AllTime")
            .put("sort", "Newest")
            .put("withMeta", false)
            .put("fromPlatform", false)
            .put("browsingLevel", if (settings.includeNsfw) 31 else 1)
            .put("include", JSONArray().put("cosmetics"))
            .put("types", JSONArray().put("image"))
            .put("limit", settings.pageSize)
            .put(
                "cursor",
                nextCursor?.let(::cursorJsonValue) ?: JSONObject.NULL,
            )

        if (settings.apiKey.isNotBlank()) {
            params.put("authed", true)
        }

        val input = JSONObject().put("json", params)
        if (nextCursor.isNullOrBlank()) {
            input.put(
                "meta",
                JSONObject().put(
                    "values",
                    JSONObject().put("cursor", JSONArray().put("undefined")),
                ),
            )
        }

        return endpoint.newBuilder()
            .setQueryParameter("input", input.toString())
            .build()
            .toString()
    }

    private fun loadGenerationPrompt(
        settings: AppSettings,
        listEndpoint: HttpUrl,
        imageId: Long,
    ): String? {
        val generationEndpoint = listEndpoint.newBuilder()
            .encodedPath("/api/trpc/image.getGenerationData")
            .query(null)
            .build()

        val params = JSONObject().put("id", imageId)
        if (settings.apiKey.isNotBlank()) {
            params.put("authed", true)
        }
        val input = JSONObject().put("json", params)
        val url = generationEndpoint.newBuilder()
            .setQueryParameter("input", input.toString())
            .build()
            .toString()

        val body = executeJson(url, settings, trpc = true)
        val root = JSONObject(body)
        return findStringByKey(unwrapTrpc(root), "prompt")
    }

    private fun parseTrpcList(raw: String): TrpcRawPage {
        val trimmed = raw.trim()
        require(trimmed.isNotEmpty()) { "Пустой ответ" }
        val root = JSONObject(trimmed)
        val data = unwrapTrpc(root)
        val items = data.optJSONArray("items")
            ?: throw IllegalArgumentException("В tRPC-ответе не найден массив items")

        val candidates = buildList {
            for (index in 0 until items.length()) {
                val item = items.optJSONObject(index) ?: continue
                parseTrpcCandidate(item)?.let(::add)
            }
        }

        return TrpcRawPage(
            candidates = candidates,
            nextCursor = scalarAsString(data.opt("nextCursor")),
        )
    }

    private fun parseTrpcCandidate(item: JSONObject): TrpcCandidate? {
        val rawId = item.opt("id")
            ?.toString()
            ?.takeIf { it.isNotBlank() && it != "null" }
        val numericId = rawId?.toLongOrNull()
        val rawUrl = sequenceOf(
            item.optString("url"),
            item.optString("imageUrl"),
            item.optString("src"),
        )
            .map(String::trim)
            .firstOrNull { it.isNotBlank() && it != "null" }

        val width = item.optInt("width", 1).coerceAtLeast(1)
        val height = item.optInt("height", 1).coerceAtLeast(1)
        val url = normalizeImageUrl(rawUrl, rawId, width) ?: return null
        val id = rawId ?: sha256(url)
        val userObject = item.optJSONObject("user")

        return TrpcCandidate(
            id = id,
            numericId = numericId,
            url = url,
            width = width,
            height = height,
            nsfwLevel = scalarAsString(item.opt("nsfwLevel"))
                ?: if (item.optBoolean("nsfw", false)) "X" else "Safe",
            prompt = findStringByKey(item, "prompt"),
            username = sequenceOf(
                item.optString("username"),
                userObject?.optString("username"),
                userObject?.optString("name"),
            )
                .filterNotNull()
                .map(String::trim)
                .firstOrNull { it.isNotBlank() && it != "null" },
        )
    }

    private fun parseRestPage(raw: String): ImagePage {
        val trimmed = raw.trim()
        require(trimmed.isNotEmpty()) { "Пустой ответ" }

        val root: JSONObject?
        val itemsJson: JSONArray
        if (trimmed.startsWith("[")) {
            root = null
            itemsJson = JSONArray(trimmed)
        } else {
            root = JSONObject(trimmed)
            itemsJson = root.optJSONArray("items")
                ?: root.optJSONArray("data")
                ?: throw IllegalArgumentException("Не найден массив items")
        }

        val items = buildList {
            for (index in 0 until itemsJson.length()) {
                val item = itemsJson.optJSONObject(index) ?: continue
                val url = firstHttpsUrl(
                    item.optString("url"),
                    item.optString("imageUrl"),
                    item.optString("src"),
                ) ?: continue
                val id = item.opt("id")
                    ?.toString()
                    ?.takeIf { it.isNotBlank() && it != "null" }
                    ?: sha256(url)

                val prompt = findStringByKey(item, "prompt") ?: continue
                val userObject = item.optJSONObject("user")
                add(
                    SourceImage(
                        id = id,
                        url = url,
                        width = item.optInt("width", 1).coerceAtLeast(1),
                        height = item.optInt("height", 1).coerceAtLeast(1),
                        nsfwLevel = scalarAsString(item.opt("nsfwLevel"))
                            ?: if (item.optBoolean("nsfw", false)) "X" else "Safe",
                        prompt = prompt,
                        username = sequenceOf(
                            item.optString("username"),
                            userObject?.optString("username"),
                            userObject?.optString("name"),
                        )
                            .filterNotNull()
                            .map(String::trim)
                            .firstOrNull { it.isNotBlank() && it != "null" },
                    ),
                )
            }
        }

        val metadata = root?.optJSONObject("metadata")
        return ImagePage(
            items = items.distinctBy(SourceImage::id),
            nextUrl = metadata?.optString("nextPage")
                ?.takeIf { it.startsWith("https://") },
            nextCursor = scalarAsString(metadata?.opt("nextCursor")),
        )
    }

    private fun validatedEndpoint(value: String): HttpUrl {
        val endpoint = value.toHttpUrlOrNull()
            ?: throw IllegalArgumentException("Некорректный HTTPS endpoint")
        require(endpoint.isHttps) { "Разрешены только HTTPS endpoint" }
        return endpoint
    }

    private fun isTrpcEndpoint(endpoint: HttpUrl): Boolean =
        endpoint.encodedPath.contains("/api/trpc/")

    private fun unwrapTrpc(root: JSONObject): JSONObject =
        root.optJSONObject("result")
            ?.optJSONObject("data")
            ?.optJSONObject("json")
            ?: root.optJSONObject("data")
                ?.optJSONObject("json")
            ?: root.optJSONObject("json")
            ?: root

    private fun normalizeImageUrl(
        rawUrl: String?,
        rawId: String?,
        width: Int,
    ): String? {
        val value = rawUrl?.trim().orEmpty()
        if (value.startsWith("https://")) return value
        if (value.startsWith("//")) return "https:$value"
        if (value.isBlank() || rawId.isNullOrBlank()) return null

        if (!value.contains('/')) {
            val requestedWidth = width.coerceIn(450, 2048)
            return "https://image.civitai.com/xG1nkqKTMzGDvpLrqFT7WA/" +
                "$value/width=$requestedWidth/$rawId.jpeg"
        }
        return null
    }

    private fun findStringByKey(value: Any?, key: String, depth: Int = 0): String? {
        if (depth > 8) return null
        return when (value) {
            is JSONObject -> {
                val direct = value.opt(key)
                if (direct is String && direct.isNotBlank() && direct != "null") {
                    direct.trim()
                } else {
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val child = value.opt(keys.next())
                        findStringByKey(child, key, depth + 1)?.let { return it }
                    }
                    null
                }
            }

            is JSONArray -> {
                for (index in 0 until value.length()) {
                    findStringByKey(value.opt(index), key, depth + 1)?.let { return it }
                }
                null
            }

            else -> null
        }
    }

    private fun extractApiError(body: String): String {
        if (body.isBlank()) return ""
        return runCatching {
            val root = JSONObject(body)
            sequenceOf(
                root.optJSONObject("error")?.optJSONObject("json")?.optString("message"),
                root.optJSONObject("error")?.optString("message"),
                root.optString("message"),
            )
                .filterNotNull()
                .map(String::trim)
                .firstOrNull { it.isNotBlank() && it != "null" }
                .orEmpty()
        }.getOrElse { body.trim().take(350) }
    }

    private fun looksLikeHtml(body: String, contentType: String): Boolean {
        val beginning = body.trimStart().take(32)
        return contentType.contains("text/html", ignoreCase = true) ||
            beginning.startsWith("<!DOCTYPE", ignoreCase = true) ||
            beginning.startsWith("<html", ignoreCase = true)
    }

    private fun firstHttpsUrl(vararg candidates: String): String? =
        candidates.firstOrNull { it.startsWith("https://") }

    private fun cursorJsonValue(value: String): Any =
        value.toLongOrNull() ?: value.toDoubleOrNull() ?: value

    private fun scalarAsString(value: Any?): String? = when (value) {
        null, JSONObject.NULL -> null
        is String -> value.trim().takeIf { it.isNotBlank() && it != "null" }
        is Number, is Boolean -> value.toString()
        else -> null
    }

    private fun sha256(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private data class TrpcRawPage(
        val candidates: List<TrpcCandidate>,
        val nextCursor: String?,
    )

    private data class TrpcCandidate(
        val id: String,
        val numericId: Long?,
        val url: String,
        val width: Int,
        val height: Int,
        val nsfwLevel: String,
        val prompt: String?,
        val username: String?,
    ) {
        fun toSourceImage(resolvedPrompt: String): SourceImage = SourceImage(
            id = id,
            url = url,
            width = width,
            height = height,
            nsfwLevel = nsfwLevel,
            prompt = resolvedPrompt,
            username = username,
        )
    }
}
